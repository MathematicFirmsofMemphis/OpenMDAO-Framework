#!/bin/bash
cat updates/auth/*.sql > ALL_auth.sql
