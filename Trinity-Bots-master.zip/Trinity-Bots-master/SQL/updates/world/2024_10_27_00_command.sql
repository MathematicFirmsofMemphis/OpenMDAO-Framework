--
INSERT IGNORE INTO `command` (`name`) VALUES
('npcbot wp setweights');
