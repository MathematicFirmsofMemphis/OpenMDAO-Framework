--
DELETE FROM `command` WHERE `name` = 'npcbot go';
INSERT INTO `command` (`name`) VALUES
('npcbot go');
