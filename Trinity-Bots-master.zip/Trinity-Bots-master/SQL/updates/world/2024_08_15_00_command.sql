--
INSERT IGNORE INTO `command` (`name`) VALUES
('npcbot free');
