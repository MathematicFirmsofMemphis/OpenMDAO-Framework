-- Marion modelId fix
UPDATE `creature_template` SET `modelid1`='1603' WHERE (`entry`='70158');
