--
DELETE FROM `command` WHERE `name` = 'npcbot recall spawns';
INSERT INTO `command` (`name`) VALUES
('npcbot recall spawns');
