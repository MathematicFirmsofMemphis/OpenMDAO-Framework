--
INSERT IGNORE INTO `command` (`name`) VALUES
('npcbot order pull');
