--
INSERT IGNORE INTO `command` (`name`) VALUES
('npcbot log clear');
