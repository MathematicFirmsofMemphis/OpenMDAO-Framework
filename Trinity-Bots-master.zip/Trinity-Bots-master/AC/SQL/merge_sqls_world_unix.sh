#!/bin/bash
cat *world_*.sql > ALL_world.sql
cat updates/world/*.sql >> ALL_world.sql
