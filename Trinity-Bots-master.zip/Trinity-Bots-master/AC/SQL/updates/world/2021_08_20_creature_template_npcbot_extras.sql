-- Kerra race fix
UPDATE `creature_template_npcbot_extras` SET `race`='10' WHERE (`entry`='70038');
