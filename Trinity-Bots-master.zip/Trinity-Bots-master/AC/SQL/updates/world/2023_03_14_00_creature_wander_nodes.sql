--
DROP TABLE IF EXISTS `creature_wander_nodes`;
