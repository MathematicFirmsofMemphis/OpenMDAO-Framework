--
DELETE FROM `command` WHERE `name` LIKE "npcbot%";
