--
ALTER TABLE `creature_template_npcbot_appearance` MODIFY COLUMN `name*` char(100) DEFAULT 'unk' COMMENT 'unused', CHARSET=utf8mb4;
