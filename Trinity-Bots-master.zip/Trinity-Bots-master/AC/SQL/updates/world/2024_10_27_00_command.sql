--
INSERT IGNORE INTO `command` (`name`,`security`,`help`) VALUES
('npcbot wp setweights', '2', NULL);
