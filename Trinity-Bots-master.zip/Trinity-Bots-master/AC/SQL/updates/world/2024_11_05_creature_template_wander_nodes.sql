--
UPDATE `creature_template_npcbot_wander_nodes` SET `minlevel`='50', `maxlevel`='80' WHERE `id`='5110';
