--
DELETE FROM `command` WHERE `name`='npcbot sendto';
INSERT INTO `command` (`name`) VALUES
('npcbot sendto');
