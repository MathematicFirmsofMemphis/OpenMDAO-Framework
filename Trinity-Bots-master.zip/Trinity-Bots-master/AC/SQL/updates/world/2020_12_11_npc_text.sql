--
DELETE FROM `npc_text` WHERE ID = 70550;
INSERT INTO `npc_text` (`ID`,`text0_0`,`VerifiedBuild`) VALUES
('70550','Bot ownership expired','-1');
