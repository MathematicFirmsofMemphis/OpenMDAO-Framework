--
DELETE FROM `command` WHERE `name`='npcbot command walk';
INSERT INTO `command` (`name`) VALUES
('npcbot command walk');
