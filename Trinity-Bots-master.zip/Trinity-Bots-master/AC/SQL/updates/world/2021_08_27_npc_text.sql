--
DELETE FROM `npc_text` WHERE ID = 70645;
INSERT INTO `npc_text` (`ID`,`text0_0`,`VerifiedBuild`) VALUES
('70645','Off-Tank','-1');
