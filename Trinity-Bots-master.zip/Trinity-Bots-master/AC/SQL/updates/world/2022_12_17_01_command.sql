--
DELETE FROM `command` WHERE `name` = 'npcbot spawned';
