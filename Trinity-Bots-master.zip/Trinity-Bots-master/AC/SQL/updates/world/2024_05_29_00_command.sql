--
INSERT IGNORE INTO `command` (`name`,`security`,`help`) VALUES
('npcbot log clear', '3', NULL);
