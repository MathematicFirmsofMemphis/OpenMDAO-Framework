--
UPDATE `npc_text` SET `text0_0`='Auto-equip' WHERE (`ID`='70489');
