--
UPDATE `creature_template_npcbot_wander_nodes` SET `flags`='1' WHERE (`id`='283');
