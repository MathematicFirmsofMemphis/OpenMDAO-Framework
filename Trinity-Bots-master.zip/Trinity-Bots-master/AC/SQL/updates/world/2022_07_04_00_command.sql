--
DELETE FROM `command` WHERE `name`='npcbot createnew';
INSERT INTO `command` (`name`) VALUES
('npcbot createnew');
