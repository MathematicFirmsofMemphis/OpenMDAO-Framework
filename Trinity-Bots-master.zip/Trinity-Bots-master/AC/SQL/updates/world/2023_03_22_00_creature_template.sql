--
UPDATE `creature_template` SET `subname`='' WHERE (`entry` BETWEEN 70501 AND 70580) AND `subname`='NULL';
