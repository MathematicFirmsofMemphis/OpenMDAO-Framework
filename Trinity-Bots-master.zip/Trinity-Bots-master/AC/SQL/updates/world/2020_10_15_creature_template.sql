--
UPDATE `creature_template` SET `unit_flags2`='16416' WHERE `entry` IN ('70551','70552');
