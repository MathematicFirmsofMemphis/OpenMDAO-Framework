--
INSERT IGNORE INTO `command` (`name`,`security`,`help`) VALUES
('npcbot order pull', '0', NULL);
