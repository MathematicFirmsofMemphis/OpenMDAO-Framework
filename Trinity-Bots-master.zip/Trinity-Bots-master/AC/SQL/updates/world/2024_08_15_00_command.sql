--
INSERT IGNORE INTO `command` (`name`,`security`,`help`) VALUES
('npcbot free', '2', NULL);
