--
DROP TABLE IF EXISTS `creature_template_npcbot_disabled_items`;
CREATE TABLE `creature_template_npcbot_disabled_items` (
  `id` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
