--
DELETE FROM `creature_template_npcbot_appearance` WHERE (`entry`='70266');
