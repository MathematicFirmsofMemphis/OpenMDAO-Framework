-- Maldryn race fix
UPDATE `creature_template_npcbot_extras` SET `race`='4' WHERE (`entry`='70413');
