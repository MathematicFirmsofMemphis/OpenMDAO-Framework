--
ALTER TABLE `characters_npcbot_transmog` MODIFY `fake_id` int(11) NOT NULL DEFAULT '-1' AFTER `item_id`;
