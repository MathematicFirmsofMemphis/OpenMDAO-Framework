ALTER TABLE `characters_npcbot` ADD `spec` tinyint(3) unsigned NOT NULL DEFAULT '1' AFTER `roles`;
