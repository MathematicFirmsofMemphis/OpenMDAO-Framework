ALTER TABLE `characters_npcbot` ADD `spells_disabled` longtext AFTER `equipNeck`;
