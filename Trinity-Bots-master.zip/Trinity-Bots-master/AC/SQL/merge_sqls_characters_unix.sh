#!/bin/bash
cat characters_bots.sql > ALL_characters.sql
cat updates/characters/*.sql >> ALL_characters.sql
